<template>
    <div>
        <slot>后备内容</slot>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>

</style>
// 云函数入口文件
const cloud = require("wx-server-sdk");
const axios = require("axios");
const doubanbook = require("doubanbook");
const cheerio = require("cheerio");
//爬虫
// https://search.douban.com/book/subject_search?search_text=9787010009148&cat=1001
cloud.init();

async function getDoubanBook(isbn) {
  const url =
    "https://search.douban.com/book/subject_search?search_text=" + isbn;
  let res = await axios.get(url);

  let reg = /window\.__DATA__ = "(.*)"/;
  if (reg.test(res.data)) {
    //第一个括号分组数据
    let searchData = doubanbook(RegExp.$1)[0];
    console.log(searchData);
    return searchData;
  }
}
getDoubanBook("9787010009148");
// 云函数入口函数
exports.main = async (event, context) => {
  let { a, b, isbn } = event;
  let bookInfo = await getDoubanBook(isbn);

  //获取详情页的信息
  const detaiPage = await axios.get(bookInfo.url);
  //使用cheerio 来解析页面，生成对象，可以使用jq语法
  const $ = cheerio.load(detaiPage.data);
  const summary = $("#link-report .intro").text();
  return {
    summary,
    sum: a + b,
    title: bookInfo.title,
    image: bookInfo.cover_url
  };
};

// pages/book/book.js
//初始化 需要先获取数据库的引用
const db = wx.cloud.database();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    src:""
  },
  scancode(){
    wx.scanCode({
      success(res) {
        //调用云函数

        wx.cloud.callFunction({
          name:"books14",
          data:{
            a:10,
            b:4,
            isbn:res.result
          },
          success:res=>{
            console.log(res)
            db.collection("web14").add({
              data: res.result,
              success:function(ret){
                console.log(ret)
              }
            })
            wx.showModal({
              title: '添加成功',
              content: '哈哈，好高兴',
            })
          }
        })
        console.log(res)
      }
    })
  }
  // takephoto(){
  //   const ctx = wx.createCameraContext()
  //   ctx.takePhoto({
  //     quality: 'high',
  //     success: (res) => {
  //       console.log(res)
  //       this.setData({
  //         src: res.tempImagePath
  //       })
  //     }
  //   })
  // }
})